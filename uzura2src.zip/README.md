# uzura2
mpeg audio layer 2 encoder written in Fortran 90/95

Never touched since 2000. 
By some strange whim, matrix indeces are ordered in C-order. 